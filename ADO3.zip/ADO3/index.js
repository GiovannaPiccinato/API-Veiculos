const express = require("express");
const olimpiadas = require('./olimpiadas.json');
const carros = require('./carros.json');
const profissoes = require('./profissoes.json');
const app = express();
const PORT = 8080;

app.get('/olimpiadas', (req,res) =>{ 
res.json(olimpiadas);
});

app.get('/carros', (req,res) =>{ 
	res.json(carros);
	});

	app.get('/profissoes', (req,res) =>{ 
		res.json(profissoes);
		});

app.listen(PORT, () => {
	console.log(`Servidor em execução em http://localhost:${PORT}`);
});